/*
 * Timers.c
 *
 *  Created on: Dec 6, 2024
 *      Author: Antonio Cirincione
 */

#include "Timers.h"

//@AC: TIM2 - 0,5s
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim2)
 {
 	if(htim2->Instance == TIM2)
 	{
 		HAL_GPIO_TogglePin(LD3_GPIO_Port, LD3_Pin);
 	}
 }
