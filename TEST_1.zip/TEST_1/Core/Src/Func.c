/*
 * Func.c
 *
 *  Created on: Dec 5, 2024
 *      Author: Antonio Cirincione
 */

#include "main.h"
#include "definizioni.h"
#include "dichiarazioni.h"

/*
 * @AC: trasmissione e ricezione tramite SPI di un buffer TX ed RX di lunghezza NcharTX_RX Bytes.
 * restituisce un valore pari a "-1" se la lettura tramite SPI non va a buon fine e in quel caso LD3 lampeggia.
 */

void SPI_TX_RX(SPI_HandleTypeDef hspi, UCHAR* TX_Buffer, UCHAR* RX_Buffer, uint8_t NcharTX_RX, uint8_t* SPI_Error)
{
	HAL_GPIO_WritePin(SPI1_CS_GPIO_Port, SPI1_CS_Pin, RESET);

	if(HAL_SPI_TransmitReceive(&hspi, (uint8_t*)TX_Buffer, (uint8_t*)RX_Buffer, NcharTX_RX, 1000) != HAL_OK)
	{
		*SPI_Error = -1;
		//HAL_GPIO_TogglePin(LD3_GPIO_Port, LD3_Pin);
	}

	HAL_GPIO_WritePin(SPI1_CS_GPIO_Port, SPI1_CS_Pin, SET);
}

