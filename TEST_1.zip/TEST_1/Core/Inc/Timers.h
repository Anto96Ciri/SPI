/*
 * Timers.h
 *
 *  Created on: Dec 6, 2024
 *  Author: Antonio Cirincione
 */

#include "main.h"

#ifndef INC_TIMERS_H_
#define INC_TIMERS_H_

//TIM2 - 0,5s
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim2);

#endif /* INC_TIMERS_H_ */
