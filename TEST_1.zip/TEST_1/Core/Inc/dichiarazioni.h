/*
 * dichiarazioni.h
 *
 *  Created on: Dec 5, 2024
 *  Author: Antonio Cirincione
 */

#include "definizioni.h"


#ifndef INC_DICHIARAZIONI_H_
#define INC_DICHIARAZIONI_H_

/*
@AC: dichiarazioni funzioni utilizzate
*/


/* file FUNC.C */

//@AC: SPI TransmitReceive FullDuplex
void SPI_TX_RX(SPI_HandleTypeDef hspi,
			   UCHAR* TX_Buffer,
			   UCHAR* RX_Buffer,
			   uint8_t NcharTX_RX,
			   uint8_t* SPI_Error);

#endif /* INC_DICHIARAZIONI_H_ */

