/* serve per attivare la funzione che setta le frequenza di lavoro del micro */
#define USB_USE_LSE_MSI_CLOCK

typedef char                UCHAR;       /* 1byte enza segno  */
typedef signed char         SCHAR;       /* 1 byte con segno */
typedef signed char         I8;          /* 1 byte con segno */
typedef char                CCHAR;       /* 1 byte senza segno */
typedef unsigned char       BOOLEAN;     /* logico */
typedef unsigned short      USHORT;      /* 2byte senza segno */
typedef signed short        SHORT;       /* 2 byte con segno */
typedef unsigned long int   UINT;        /* 4byte senza segno */
typedef signed long int     INT;         /* 4byte con segno */
typedef float               FLOAT;       /* 4byte in singola precisione */
typedef float               F32;       /* 4byte in singola precisione */
typedef double              DOUBLE;      /* 4byte in singola precisione */
typedef void *              PVOID;       /*   */
typedef char                UINT8;       /* 1byte enza segno  */
typedef unsigned int        UINT16;      /* 2byte senza segno */
typedef unsigned long int   UINT32;      /* 4byte senza segno */
typedef unsigned long long  ULONG64;     /* 8byte senza segno */
typedef signed long int     INT32;      /* 4byte senza segno */
typedef signed long long    LONG64;     /* 8byte senza segno */
typedef unsigned short      U16;         /* 2byte senza segno */


#define TIPO_UCHAR	               0
#define TIPO_USHORT               1
#define TIPO_LONG	                2
#define TIPO_FLOAT	               3

#define PIGRECO        3.1415926
#define RADICE2        sqrt(2)

#define BIT0    0x01
#define BIT1    0x02
#define BIT2    0x04
#define BIT3    0x08
#define BIT4    0x10
#define BIT5    0x20
#define BIT6    0x40
#define BIT7    0x80


#define GRUPPO_LED_1            1
#define GRUPPO_LED_2            2
#define GRUPPO_LED_3            3

#define LED_OFF                  0
#define LED_R_ON                 1
#define LED_G_ON                 2
#define LED_RG_ON                3

#define ON                       1
#define OFF                      0

#define MAX_NUMERO_MODELLI       3

#define MAX_PARAM_CAL           20
#define MAX_PARAM               50


#define ON                        1
#define OFF                       0
#define TOGGLE                    2
#define FALSE 		                0
#define TRUE  	                  1
#define LEGGI_SERIALE             0
#define SCRIVI_SERIALE            1

#define ADRS_EEPROM_24FC256    0xA0
#define LEGGI_DA_MEMORIA          0
#define SCRIVI_IN_MEMORIA         1

/* DEFINIZIONI PER SERIALE  */
#define  MAX_CHAR_RX            256
#define  MAX_CHAR_TX          10000

#define  MAX_CHAR_TX1           256

#define MAX_LEN_MSG_I            35

#define S_SOH	  	0x01
#define S_SOH2	 	0x02
#define S_EOT		  0x04
#define S_LF		  0x0A
#define S_ACK		  0x06
#define S_NAK		  0x15
#define S_DLE		  0x10
#define S_OK      0x30
#define S_NOK     0x31
#define S_BUSY    0x32
#define S_BNOK    0x33
#define S_NENA    0x34
#define S_CR			0x13
#define S_HOME	  0x11

/* definizione pin IO */
#define EEPROM_WP_OFF                   HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET)
#define EEPROM_WP_ON                    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET)


#define WGM160PX22                0
#define DA16200MOD                1

#define WIFI_ON                         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET)
#define WIFI_OFF                        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET)
#define WIFI_RESET_ON                   HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, GPIO_PIN_RESET)
#define WIFI_RESET_OFF                  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, GPIO_PIN_SET)
#define WIFI_SEND_DATI                  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_RESET)
#define WIFI_SEND_COMMAND               HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_SET)
/* lettura pin busy wifi */
#define PIN_BUSY                        HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13)
/* lettura pin interrupt */
#define PIN_IN_INT                      HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_12)
#define WIFI_INT_PIN                    GPIO_PIN_12

#define PIN_VIN                         HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_6)
#define WIFI_INT_LAMP                   GPIO_PIN_15

#define PIN_IN_RX                       HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_11)

#define K1_ON                           HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET)
#define K1_OFF                          HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET)
#define K101_ON                         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_SET)
#define K101_OFF                        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET)

#define PIN_DEBUG_TP11_ON               HAL_GPIO_WritePin(GPIOA, GPIO_PIN_12, GPIO_PIN_SET)
#define PIN_DEBUG_TP11_OFF              HAL_GPIO_WritePin(GPIOA, GPIO_PIN_12, GPIO_PIN_RESET)
#define PIN_DEBUG_TP11_TOGGLE           HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_12)

#define CMD_K1_ON                         0
#define CMD_K101_ON                       1
#define CMD_K1_K101_OFF                   2

#define CANALE_V_BOCCOLE                  0
#define CANALE_SINGOLO                    1

#define COUNTS_200_MICRO               7333
#define COUNTS_100_MICRO               3666

#define COUNTS_500_MILLI               50000
#define COUNTS_250_MILLI               25000


#define TENSIONE_C1C2       0
#define TENSIONE_P1P2       1
#define TENSIONE_P1C2       2
#define TENSIONE_P2C1       3
#define TENSIONE_P1C1       4
#define TENSIONE_P2C2       5
#define TENSIONE_SAVE_C1C2       6
#define TENSIONE_SAVE_P1P2       7
#define TENSIONE_SAVE_P1C2       8
#define TENSIONE_SAVE_P2C1       9
#define TENSIONE_SAVE_P1C1      10
#define TENSIONE_SAVE_P2C2      11
#define TENSIONE_AC_C1C2       6
#define TENSIONE_AC_P1P2       7
#define TENSIONE_AC_P1C2       8
#define TENSIONE_AC_P2C1       9
#define TENSIONE_AC_P1C1      10
#define TENSIONE_AC_P2C2      11

/* indice delle boccole */
#define C1         0
#define P1         1
#define P2         2
#define C2         3

/* limite V in ingresso */
#define  LIMITE_MAX_VINPUT           5 // tensione max alle boccole

//
//#define SPI_LCD_1                              3
//
//#define SPI_ADC_1                              2
//#define SPI_ADC_1_CLK_ENABLE()                __HAL_RCC_SPI2_CLK_ENABLE()
//#define SPI_ADC_1_SCK_GPIO_CLK_ENABLE()       __HAL_RCC_GPIOB_CLK_ENABLE()
//#define SPI_ADC_1_MISO_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOB_CLK_ENABLE()
//#define SPI_ADC_1_MOSI_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOB_CLK_ENABLE()
//
//#define SPI_ADC_1_SCK_PIN                     GPIO_PIN_13
//#define SPI_ADC_1_SCK_GPIO_PORT               GPIOB
//#define SPI_ADC_1_SCK_AF                      GPIO_AF5_SPI2
//
//#define SPI_ADC_1_MOSI_PIN                    GPIO_PIN_15
//#define SPI_ADC_1_MOSI_GPIO_PORT              GPIOB
//#define SPI_ADC_1_MOSI_AF                     GPIO_AF5_SPI3
//
//#define SPI_ADC_1_MISO_PIN                    GPIO_PIN_14
//#define SPI_ADC_1_MISO_GPIO_PORT              GPIOB
//#define SPI_ADC_1_MISO_AF                     GPIO_AF5_SPI1
//
//#define ENABLE_CS_LCD                   HAL_GPIO_WritePin(GPIOA, GPIO_PIN_11, GPIO_PIN_RESET)
//#define DISABLE_CS_LCD                  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_11, GPIO_PIN_SET)
//#define ENABLE_CD_LCD                   HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_SET)
//#define DISABLE_CD_LCD                  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_RESET)
//#define RESET_LCD_OFF                   HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_SET)
//#define RESET_LCD_ON                    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_RESET)
//
//
//#define ADP5587_WRITE          0x68
//#define ADP5587_READ           0x69
//

//
//#define ADRS_ADP5587           0x68


//
//typedef struct GESTIONE_SPI_DSP_MICRO {
//    UCHAR semaforo;
//    UCHAR chEn;
//    UCHAR selezioneSpi;
//    UCHAR EnSetting;
//    UCHAR DecizIntH;
//    UCHAR DecizIntL;
//    UCHAR DecizDecH;
//    UCHAR DecizDecL;
//    SPI_HandleTypeDef SpiHandle;
//    UINT8 tx[50];
//    UINT8 rx[50];
//} GESTIONE_SPI_DSP_MICRO;
//


typedef struct
{
    UCHAR semaforoI2C;
    uint16_t DevAddress;
    uint8_t Data[100];
    uint16_t Size;
    uint32_t Timeout;
} STRUCT_I2C;


/* struttura per la misura di tensione alle boccole */
typedef struct   
{
    FLOAT VC1C2dc;
    FLOAT VP1P2dc;
    FLOAT VP1C2dc;
    FLOAT VP2C1dc;
    FLOAT VP1C1dc;
    FLOAT VP2C2dc;
    FLOAT VC1C2ac;
    FLOAT VP1P2ac;
    FLOAT VP1C2ac;
    FLOAT VP2C1ac;
    FLOAT VP1C1ac;
    FLOAT VP2C2ac;
    FLOAT Vmax;
} VBOCC_STRUCT;

typedef struct {
    /* MISURA */
    UCHAR tipoMisuraLow;
    UCHAR tipoStrumento; 
    UCHAR distributore;  
    UCHAR modoMisura;
    UCHAR erroreI2C;
    UCHAR anno;
    UCHAR mese;
    UCHAR giorno;
    USHORT TRes;
    FLOAT TresFloat;
    USHORT limTempRes;
    UCHAR versioneHW;
    UCHAR WiFiPresente;
    USHORT valCHV;
    USHORT valCHI;
    UCHAR codiceErrore;
    FLOAT resistenza;
    FLOAT tensione;
    FLOAT corrente;
    FLOAT valMedioV;
    FLOAT valMedioI;
    UCHAR readCHADC12;
    UCHAR datiDaWiFi;
    USHORT datiDaRicevereWiFi;
    USHORT datiDaInviareWiFi;
    UCHAR command;
    INT baudRate;
    UCHAR EsitoCmdWiFi;
    UCHAR erroreWiFi;
    UCHAR stepInitWiFi;
    UCHAR doveRispondere;
    UCHAR enableMisura;
    UCHAR errore;
    UCHAR lampeggioLedWiFi;
    UCHAR tipoWiFi;
    UCHAR msgWiFiRic;
    USHORT copiaIndexWiFi;
    UCHAR stepLampeggio;
    UCHAR ledFissi;
    USHORT nCharRx;
    
} val_misure;
        
typedef union {
    UINT mDByteEn;
    struct mBitEn {
        UCHAR EN_STANDBY             :1;  // 0
        UCHAR EN_MIS_VBOCC           :1;  // 1
        UCHAR EN_CALCOLOVBOCC        :1;  // 2
        UCHAR EN_CALCOLO             :1;  // 3
        UCHAR EN_ACQ_LOW             :1;  // 4
        UCHAR EN_MISURA_LOW          :1;
        UCHAR EN_ACQUI_12            :1;  // abilita acquisizione canale ADC12
        UCHAR EN_AUTO_START          :1;
        UCHAR EN_START_MIS           :1;
        UCHAR STATO_AUTO             :1;
        UCHAR EN_500_SAMPL           :1;  // 10
        UCHAR EN_4                   :1;  // 11
        UCHAR EN25                   :1;  // 12
        UCHAR EN26                   :1;  // 13
        UCHAR EN_5                   :1;  
        UCHAR EN27                   :1;  
        UCHAR EN_6                   :1;  
        UCHAR EN_7                   :1;  
        UCHAR EN_8                   :1;  
        UCHAR EN35                   :1;  
        UCHAR EN_9                   :1;  // 20
        UCHAR EN37                   :1;
        UCHAR EN_10                  :1;
        UCHAR EN21                   :1;
        UCHAR EN_11                  :1;
        UCHAR EN28                   :1;
        UCHAR EN29                   :1;
        UCHAR EN30                   :1;
        UCHAR EN_12                  :1;
        UCHAR EN32                   :1;
        UCHAR EN_13                  :1;
    }mBitEn;
} DByteBitEn;


///* definizioni degli indirizzi dei parametri */
#define ADRS_MATR                             0x00       /* 4 bytes matricola strumento */
#define ADRS_DISTR                            0x04       /* 1 byte distributore */
#define ADRS_TIPO_STR                         0x05       /* 1 byte tipo strumento */
#define ADS_GG_CAL                            0x06       /* 1 byte contiene il giorno della calibrazione */
#define ADS_MM_CAL                            0x07       /* 1 byte contiene il mese della calibrazione */
#define ADS_YY_CAL                            0x08       /* 1 byte contiene l'anno della calibrazione */
#define ADS_K_LOW                             0x09       /* 2 bytes fattore K della misura di resistenza */
#define ADS_O_LOW                             0x0B       /* 2 bytes offset della misura di resistenza */
#define ADS_K_I                               0x0D       /* 2 bytes fattore K della misura corrente */
#define ADS_O_I                               0x10       /* 2 bytes offset della misura di corrente */
#define ADS_OFS_VAD1                          0x12       /* 2 bytes offset del canale 1 del micro */
#define ADS_OFS_VAD2                          0x14       /* 2 bytes offset del canale 2 del micro */
#define ADS_OFS_VAD3                          0x16       /* 2 bytes offset del canale 3 del micro */
#define ADS_OFS_VAD4                          0x18       /* 2 bytes offset del canale 4 del micro */
#define ADS_LIM_T                             0x1A       /* 2 bytes limite temperatura per abilitare la prova in bits */
#define ADS_KV_C1C2                           0x1C       /* 2 fattore K tensione letta tra C1 e C2 */
#define ADS_KV_P1P2                           0x1E       /* 2 fattore K tensione letta tra P1 e P2 */
#define ADS_KV_P1C2                           0x20       /* 2 fattore K tensione letta tra P1 e P2 */
#define ADS_KV_P2C1                           0x22       /* 2 fattore K tensione letta tra P1 e P2 */
#define ADS_KV_P1C1                           0x24       /* 2 fattore K tensione letta tra P1 e P2 */
#define ADS_KV_P2C2                           0x26       /* 2 fattore K tensione letta tra P1 e P2 */
#define ADS_O_CHV                             0x28       /* 2 offset del canale di misura V */
#define ADS_O_CHI                             0x2A       /* 2 offset del canale di misura I */
#define ADS_LED_WIFI                          0x2C       /* 1 Abilita lampeggio led stato WiFi = 170 lamp */

#define ADS_PRET                              0x2E       /* 1 memorizza l'avvenuto pretest del fornitore */


///* ATTENZIONE PROSSIMA CELLA LIBERA */
#define NEXT_FREE_CELL                        0x2E


#define PAR_ADS_K_LOW                0
#define PAR_ADS_O_LOW                1

#define PAR_ADS_K_I                  2
#define PAR_ADS_O_I                  3

#define PAR_ADS_K_C1C2               4
#define PAR_ADS_K_P1P2               5
#define PAR_ADS_K_P1C2               6
#define PAR_ADS_K_P2C1               7
#define PAR_ADS_K_P1C1               8
#define PAR_ADS_K_P2C2               9


/* canali singoli di ADC del micro */
#define CH_VIN_C1               0
#define CH_VIN_P1               1
#define CH_VIN_P2               2
#define CH_VIN_C2               3
#define CH_VOLTAGE              4
#define CH_CURRENT              5
#define CH_TRES                 6
#define CH_VER_HW               7
#define CH_V_INPUT              8

#define N_CICLI_VBOCC          2000
#define N_CICLI_MISURA         2000

#define MAX_CAMPIONI           2100

#define TIME_BAUD_RATE     13000 / 57600


enum codErrori {
    NO_ERRORE,            // 0
    ERR_EEPROM,           // 1 errore in lettura/scrittura 
    ERR_RTC_MICRO,        // 2 Errore del RTC    
    ERRORE_INIT,          // 3 errore generico
    HIGH_VOLT,            // tensione alle boccole
    HOT,                  // resistenze calde troppo
    ERRORE_WIFI,
    
};


/* costante per tensione letta a 12 bits */
//#define K_BITS_VOLT_ADC12             0.041   // V = bits * K
//#define K_BITS_VOLT_ADC16        1050.13 // V = bits / K
//#define K_BITS_CURR_ADC16         801.72 // I = bits / K
// OLD #define K_BITS_VOLT_ADC12             0.00763   // V = bits * K
/* NEW 29/11/2021 */
#define K_BITS_VOLT_ADC12             0.01297   // V = bits * K
// OLD #define K_BITS_VOLT_ADC16          1046.48 // V = bits / K
/* NEW 29/11/2021 */
#define K_BITS_VOLT_ADC16           1233.62 // V = bits / K
#define K_BITS_CURR_ADC16           801.72 // I = bits / K
/* K per misurare la tensione di alimentazione */
#define K_BITS_VOLT_VIN             4.44


//#define CAMPIONI_640           640
//#define CAMPIONI_100           100
//#define CAMPIONI_2000         2000


//#define MAX_CAMPIONI           128
//#define MAX_CAMPIONI_256       256
//#define MAX_CAMPIONI_640       640


//#define RX_BUFFERSIZE                4096
//#define TX_BUFFERSIZE                1300
//#define BUFFERSIZE_STAT               500

#define DISTR_HT                                 0
#define DISTR_TIS                                1
//
#define MAX_DISTRIBUTORI                         1
#define MAX_TIPOSTRUM                            2


#define SPI_ADC_1                              1
#define SPI_ADC_1_CLK_ENABLE()                __HAL_RCC_SPI1_CLK_ENABLE()
#define SPI_ADC_1_SCK_GPIO_CLK_ENABLE()       __HAL_RCC_GPIOA_CLK_ENABLE()
#define SPI_ADC_1_MISO_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOA_CLK_ENABLE()
#define SPI_ADC_1_MOSI_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOA_CLK_ENABLE()

#define SPI_ADC_1_SCK_PIN                     GPIO_PIN_5
#define SPI_ADC_1_SCK_GPIO_PORT               GPIOA
#define SPI_ADC_1_SCK_AF                      GPIO_AF5_SPI1

#define SPI_ADC_1_MOSI_PIN                    GPIO_PIN_7
#define SPI_ADC_1_MOSI_GPIO_PORT              GPIOA
#define SPI_ADC_1_MOSI_AF                     GPIO_AF5_SPI1

#define SPI_ADC_1_MISO_PIN                    GPIO_PIN_6
#define SPI_ADC_1_MISO_GPIO_PORT              GPIOA
#define SPI_ADC_1_MISO_AF                     GPIO_AF5_SPI1

#define CS_ADC_HIGH        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
#define CS_ADC_LOW         HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);

#define NO_OP_ADC              0x00
#define READ_REFDAC_A          0x10
#define READ_REFDAC_B          0x20
#define READ_CFR               0x30
#define WRITE_CFR              0x80 //@AC: CFR[15:12], CFR[11:0] = Function bits.
#define WRITE_REFDAC_A         0x90
#define WRITE_REFDAC_B         0xB0

#define USE_ONLY_SDO_A         0x04

typedef struct BUFFER_CAMPIONI {
    INT canale0[384];
    INT canale1[384];
    INT canale2[384];
    INT canale3[384];
    INT acqSeriale[640];
    USHORT indiceSeriale;
    UCHAR startAcquisSer;
    UINT32 indice;
    UINT32 cicliTotali;
  
} BUFFER_CAMPIONI;

#define STANDBY_WIFI              0
#define DATI_PRESENTI_WIFI        1
#define ATTESA_DATI_WIFI          2

/* elenco comandi WIFI */
#define CMD_RESET                  0x00
#define ADRS_BAUDRATE              0x03
#define ADRS_VER_FW                0x04
#define ADRS_MODFUN                0x20
#define ADRS_STATO                 0x40

#define CMD_READ_NDATA             0x30
#define CMD_WRITE_NDATA            0x31

#define CMD_READ_SSID              0x10

#define CMD_READ_DATA              0x7F

#define RISPOSTA_UART_FISICA        0
#define RISPOSTA_UART_WIFI          1

#define SOGLIA_V_ALIMENTAZIONE      160

#define COMANDO_AT_WIFI_DATA_MODE             0
#define COMANDO_AT_WIFI_VERSIONE              1
#define COMANDO_AT_WIFI_WFMODE_0              2
#define COMANDO_AT_WIFI_RESTART               3
#define COMANDO_AT_WIFI_NWIP                  4
#define COMANDO_AT_WIFI_NWDHS                 5
#define COMANDO_AT_WIFI_NWDHR                 6
#define COMANDO_AT_WIFI_WFSAP                 7
#define COMANDO_AT_WIFI_WFMODE_1              8
#define COMANDO_AT_WIFI_TRSAVE                9
#define COMANDO_AT_WIFI_ATZ                  10
#define COMANDO_AT_WIFI_SET_PORTA            11
#define COMANDO_AT_WIFI_115200               12
#define COMANDO_AT_WIFI_57600                13
#define COMANDO_AT_WIFI_WFCC                 14
#define COMANDO_AT_WIFI_GENERICO             15
#define COMANDO_AT_WIFI_ATF                  16

/* EOF */
